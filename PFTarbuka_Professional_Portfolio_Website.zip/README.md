# P. F. Tarbuka — Professional Portfolio

This is a simple, responsive, static portfolio website for professional use.

## Preview
Open `index.html` in a browser.

## Publish for free with GitHub Pages
1. Create/sign in to a GitHub account at https://github.com/.
2. Create a new **public** repository named `pftarbuka.github.io` (if that exact name is available).
3. Upload `index.html` to the repository root and commit the file.
4. In the repository, open **Settings → Pages** and enable deployment from the `main` branch and `/ (root)` if needed.
5. Wait for GitHub Pages to publish. Your URL should be `https://pftarbuka.github.io/` if the username/repository name match exactly.
6. Open the URL in a private/incognito window to verify it works before submitting it.

If your GitHub username differs, use the repository's Pages URL shown in GitHub Settings instead. Do not submit the expected URL until it is live and tested.

## Important
Review all wording before publishing. The page intentionally distinguishes research interests, ongoing work and concepts from completed/validated products. Add evidence links (publications, project demos, code, reports) where available. Remove anything you do not wish to make public.
